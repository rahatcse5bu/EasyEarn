
<div class="container">
  <div class="row">
    <div class="col-sm">
     <!--- One of three columns ---->
    </div>
    <div class="col-sm">
	



<div class="signup-form" style="background-color:#ced9d1">
 <form action="" method="post">
<div class="form-header">
<h2>Withdraw Form</h2>
<p>Fill out this form to Withdraw!</p>
</div>



<div class="form-group">
    <label class="control-label">Payment Method</label>
    <div class="inputGroupContainer">
     <div class="input-group">
      <span class="input-group-addon" style="max-width: 100%;"><i class="glyphicon glyphicon-list"></i></span>
       <select class="selectpicker form-control" name="wpp">
       <option>Select Payment Method </option>
            <option value="bkash">Bkash</option>
			<option value="rocket">Rocket</option>
			<option value="payoner">Payoner</option>
			<option value="bitcoin">Bitcoin</option>
       </select>
       </div>
       </div></div>


<div class="form-group">
  <label class="control-label">Phone Number/Email</label>
   <div class="inputGroupContainer">
   <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span><input id="phoneNumber" name="wphoneNumber" placeholder="Phone Number" class="form-control" required="true" value="" type="text"></div>
   </div>
    </div>
	
	<div class="form-group">
  <label class="control-label">Amount</label>
   <div class="inputGroupContainer">
   <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span><input id="amount" name="amount" placeholder="Amount" class="form-control" required="true" value="" type="text"></div>
   </div>
    </div>
	<div class="form-group">
  <label class="control-label">Current Password</label>
   <div class="inputGroupContainer">
   <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span><input id="password" name="pas" placeholder="Password" class="form-control" required="true" value="" type="password"></div>
   </div>
    </div>
	<div align="center">
	<div class="form-group" align="center" >
    <div class="inputGroupContainer" align="center">
     <div class=" input-group" align="center"><span class="input-group-addon"></span><button type="submit" class="btn btn-primary" name="withdraw">Withdraw</button>
     </div>
    </div></div></div>
	
	</form>
	</div>
	
	
	
                         
     </div> 
    <div class="col-sm">
    <!---  One of three columns --->
    </div>
  </div>
</div>                        