$('#username').keyup(function(){
var username=$('#username').val();
if (username.length<8){
	$('#err').text("Username Should be at least 7 character long");
	
}
else{
	$('#err').text('');
}
//$('#err').text('hi broooooooooo');
});


$('#submit').submit(function(){

return false;




});
$(document).ready(function(){
//alert("Hi Rahat");

});

