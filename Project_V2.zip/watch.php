<?php





include "config.php";
//include"database.php";
$d=date("Y_m_d");
$sqlForDate="CREATE TABLE IF NOT EXISTS $d (
D Date ,
username VARCHAR(80),
ads INT(9) NOT NULL DEFAULT 0,
 PRIMARY KEY(username)

);";
$c=0;
$resultForDate=$con->query($sqlForDate);
$sqlForUserInsert="INSERT IGNORE INTO $d SET username='$u';";
$resultForUserInsert=$con->query($sqlForUserInsert);
if($resultForUserInsert){
//echo "insertion True";	
}
$sqlForCount="SELECT * FROM $d WHERE username='$u'";
$resultForCount=$con->query($sqlForCount);
if($resultForCount){
while($roo=mysqli_fetch_assoc($resultForCount)){
	$c=$roo['ads'];
	
}
//echo "  true7";
}
if($c<20){
$u=$_SESSION['username'];
//$d=date("Y/m/d");
$c=$c+1;
$sql="UPDATE $d SET ads='$c' WHERE username='$u'";
$result=$con->query($sql);
if ($result){
	
	//echo "Watched";
}
else{
	echo "Error Occuredddddddddddddd".$con->error;
}

echo "\nYou Have Watched :".$c."  "."Ads Left For Today :"; echo 20-$c;

}
else{
	echo "You Have Already Watched all the ads";
}
?>









