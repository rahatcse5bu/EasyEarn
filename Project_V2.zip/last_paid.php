
<?php
echo'<table class="table table-sm table-dark" "table-responsive"><thead><tr><th scope="col">Invoice ID</th><th scope="col">Payment Method</th><th scope="col">Email/Phone</th><th scope="col">Amount</th><th scope="col">Requested On</th></tr></thead><tbody><tr>';
$sqlForInvoice="SELECT * FROM invoice WHERE status='Paid'";
$resultForInvoice=$con->query($sqlForInvoice);
if($resultForInvoice){
	while($r=mysqli_fetch_assoc($resultForInvoice)){
		
		echo '<th scope="row">'.$r["id"].'</th>';
		echo '<th scope="row">'.$r["method"].'</th>';
		echo '<th scope="row">'.$r["phone"].'</th>';
		echo '<th scope="row">'.$r["amount"].'</th>';
		//echo '<th scope="row">'.$r["status"].'</th>';
		echo '<th scope="row">'.$r["Requested"].'</th>';
      
    echo '</tr>';
		
		
	}
	
	
}
      
    
   
  echo '</tbody></table>';


?>