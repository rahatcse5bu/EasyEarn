<pre><code>

</code></pre>
<pre><code>

</code></pre>
<pre><code>

</code></pre>
<pre><code>

</code></pre>

<div class="table-responsive">
<table class="table table-dark table-bordered table-hover">
  <thead>
    <tr>
      <th scope="col" class="bg-primary">Refer Link</th>
      <th scope="col" class="bg-primary">Your Refer</th>
      <th scope="col" class="bg-primary">Refer Commision</th>
      <th scope="col" class="bg-primary">Handle</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row" class="bg-info">http://localhost/ptc/?ref=<?php include "database.php"; echo$u; ?></th>
      <td class="bg-info">6</td>
      <td class="bg-info">10%</td>
      <td class="bg-info"><?php include "database.php"; echo$u; ?></td>
    </tr>
 
  </tbody>
</table>

</div>