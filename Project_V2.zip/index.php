
<?php
session_start();

?>

<html>
<head>
<!---
<link rel="stylesheet" href="b/bootstrap.min.css"/>

!--->
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

<!-- Extra For Sign Up Page !--->
<link href="https://fonts.googleapis.com/css?family=Roboto|Courgette|Pacifico:400,700" rel="stylesheet">
<!-- Extra For Sign Up Page Ends !--->
<link rel="stylesheet" href="b/loginModal.css"/>
<link rel="stylesheet" href="b/SignUpModal.css"/>



</head>

<body>

<!-- Header Div Starts -->




<div style="height: 70px; background-color: rgba(0, 138, 37,0.9);">

			
<div class="container">
  <div class="row">
    <div class="col">
	<!-- Logo Goes Here !-->
	<img src="logo.png" height="75" width="80"/>
	
	</div>
    <div class="col">
	
<nav class="navbar navbar-expand-lg navbar-light ">

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
     <li class="nav-item"><a href="#homeModal" class="nav-link" "trigger-btn" data-toggle="modal">Home</a></li>
	<li class="nav-item"><a href="#advertiseModal" class= "nav-link" "trigger-btn" data-toggle="modal">Advertise</a></li>
	<li class="nav-item"><a href="#contctModal" class="nav-link" "trigger-btn" data-toggle="modal">Contact</a></li>
    <li class="nav-item"><a href="#adsModal" class= "nav-link" "trigger-btn" data-toggle="modal">Watch Ads</a></li>
	 <li class="nav-item"><a href="#loginModal" class="nav-link" "trigger-btn" data-toggle="modal">Login</a></li>
	<li class="nav-item"><a href="#SignUpModal" class= "nav-link" "trigger-btn" data-toggle="modal">Sign Up</a></li>
	 
	 
      
    </ul>
   
  </div>
</nav>
</div>

</div>
    
  </div>
</div>	

<!-- Modal Login Starts -->
<div id="loginModal" class="modal fade">
	<div class="modal-dialog modal-login">
		<div class="modal-content">
			<form action="" method="post">
				<div class="modal-header">				
					<h4 class="modal-title">Login</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">				
					<div class="form-group">
						<label>Username</label>
						<input type="text" class="form-control" required="required" name="usernameInpt">
					</div>
					<div class="form-group">
						<div class="clearfix">
							<label>Password</label>
							<a href="#" class="pull-right text-muted"><small>Forgot?</small></a>
						</div>
						
						<input type="password" class="form-control" required="required" name="passInpt">
					</div>
				</div>
				<div class="modal-footer">
					<label class="checkbox-inline pull-left"><input type="checkbox"> Remember me</label>
					<input type="submit" class="btn btn-primary pull-right" value="Login" name="login">
				</div>
			</form>
		</div>
	</div>
</div>     


<!--- Login Modal Ends !--->


<!--- Sign Up Modal Starts !--->
			
			
			
			
<div id="SignUpModal" class="modal fade">
	<div class="modal-dialog modal-login">
		<div class="modal-content">
		
		
	<div class="signup-form">
    <form action="" method="post">
		<div class="form-header">
			<h2>Sign Up</h2>
			<p>Fill out this form to register!</p>
		</div>
        <div class="form-group">
			<label>Username</label><div id="err" style="color:#eb2617"></div>
        	<input type="text" class="form-control" name="username" required="required" id="username">
        </div>
        <div class="form-group">
			<label>Email Address</label>
        	<input type="email" class="form-control" name="email" required="required">
        </div>
		<div class="form-group">
			<label>Password</label>
            <input type="password" class="form-control" name="password" required="required">
        </div>
		<div class="form-group">
			<label>Confirm Password</label>
            <input type="password" class="form-control" name="confirm_password" required="required">
        </div>        
        <div class="form-group">
			<label class="checkbox-inline"><input type="checkbox" required="required"> I accept the <a href="#">Terms of Use</a> &amp; <a href="#">Privacy Policy</a></label>
		</div>
		<div class="form-group">
			<button type="submit" class="btn btn-primary btn-block btn-lg" name="submit" id="submit">Sign Up</button>
		</div>	
    </form>
	<div class="text-center small">Already have an account? <a href="#loginModal" class="nav-link" "trigger-btn" data-toggle="modal">Login here</a></div>
</div>


</div></div></div>
<!--- Sign Up Modal Ends !--->
			
			
<!-- Modal Advertise Starts -->
<div id="advertiseModal" class="modal fade">
	<div class="modal-dialog modal-login">
		<div class="modal-content">
			<form action="" method="post">
				<div class="modal-header">				
					<h4 class="modal-title">Login</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">				
					<div class="form-group">
						<label>Username</label>
						<input type="text" class="form-control" required="required" name="usernameInpt">
					</div>
					<div class="form-group">
						<div class="clearfix">
							<label>Password</label>
							<a href="#" class="pull-right text-muted"><small>Forgot?</small></a>
						</div>
						
						<input type="password" class="form-control" required="required" name="passInpt">
					</div>
				</div>
				<div class="modal-footer">
					<label class="checkbox-inline pull-left"><input type="checkbox"> Remember me</label>
					<input type="submit" class="btn btn-primary pull-right" value="Login" name="login">
				</div>
			</form>
		</div>
	</div>
</div>     


<!--- Advertise Modal Ends !--->			
			
			
			
			



<div style="height: 450px; background-color: rgba(100, 120, 90,0.9);">
<div class="container">

  <div class="row">
    <div class="col-sm-3">
<br><br><br>

      Earn Money Online Just Viewing Ads On Daily Basis. You Will Be Served With 70 Ads Daily. Stay With EasyEarn & Earn Money Online 
    <br><br><br>
	</div>

<div class="col-sm-6">

<!--- Slide Part Goes Here !--->
<div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/Barishal_University_Campus%2C_Bangladesh.jpg/450px-Barishal_University_Campus%2C_Bangladesh.jpg" class="d-block w-100" alt="..." height="450" width="400" >
    </div>
    <div class="carousel-item">
      <img src="https://upload.wikimedia.org/wikipedia/commons/3/30/Barisal_University_on_Independence_day.jpg" class="d-block w-100" alt="..." height="450" width="400">
    </div>
    <div class="carousel-item">
      <img src="https://media.licdn.com/dms/image/C511BAQHFoh_fznfXNg/company-background_10000/0?e=2159024400&v=beta&t=iRJiZrRCZLXtbwBbmk3SdTmFGEl_8s14wVTJpxuLcBY" class="d-block w-100" alt="..." height="450" width="400">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<!--- Slide Ends --->
</div>

<div class="col-sm-3">
     <font face="Roboto"> 
	 <br><br><br>Dear Advertisers, You Can Publish Your Online Assets Here. We have More Than 5K Daily Active Users. 
	 <br><br><br>
	 </font>
    </div>
  </div>
  
 
</div>


</div>

<!--- Slide Div Ends --->





<div style="height: 200px; background-color: rgba(13, 189, 130,0.9);">

<div class="container">
  <div class="row">
    <div class="col-sm">
   <p class="text-success" style="font-size:34px" >  <i class="far fa-user"></i>  Total Users </p>
    </div>
    <div class="col-sm">
         <p class="text-success" style="font-size:34px" > <i class="fas fa-dollar-sign"></i> Total Paid </p>
    </div>
    <div class="col-sm">
         <p class="text-success" style="font-size:34px" >  <i class="fas fa-eye-slash"></i> Total Ad Views </p>
    </div>
  </div>
  
  <!--- values -->
  <div class="row">
    <div class="col-sm">
   <p class="text-success" style="font-size:34px" > 3 </p>
    </div>
    <div class="col-sm">
         <p class="text-success" style="font-size:34px" >0 </p>
    </div>
    <div class="col-sm">
         <p class="text-success" style="font-size:34px" >  2</p>
    </div>
  </div>
</div>

</div>
<div style="height: 200px; background-color: rgba(94, 78, 15,0.9);">
<?php include "config.php"; include "last_paid.php"; ?>

</div>

<div style="height: 300px; background-color: rgba(15, 15, 15,0.9);">

<div class="container" >
  <div class="row">
    <div class="col">
	 <div class="col">Developed By: </div><div class="col">Md. Rahat</div><div class="col">Nawshin Tabassum</div><div class="col">Md. Tarikul Islam</div>
	<div class="col">&copy EasyEarn.Xyz  <?php date("Y"); ?></div>
	</div>
	
    <div class="col">
	<div class="col">About Us</div><div class="col">Advertise Us</div><div class="col">Help Us</div><div class="col">Contact Us</div>
	</div>
 
  </div>
 
  
</div>


</div>







<script
  src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
  integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8="
  crossorigin="anonymous"></script>

<script src="rahat.js"></script>
<script type="javascript"> $('#myModal').on('shown.bs.modal', function () {
  $('#myInput').trigger('focus')
});  </script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<!---<script src="b/jquery.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="b/popper.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script type="text/javascript" src="b/bootstrap.min.js"></script>
!-->
</body>


</html>

<?php 

include "config.php";
include "database.php";
if(isset($_POST['submit'])){
	$username=$_POST['username'];
	$_SESSION['username']=$username;
	$email=$_POST['email'];
	$pass=md5($_POST['password']);
	$ref=$_GET['ref'];
	$msgTable=$username."_"."msg";
	$ntfTable=$username."_"."ntf";
	$sql="INSERT INTO user SET username='$username',email='$email',pass='$pass',Ref='$ref';";
	$sql1="INSERT INTO balance SET username='$username';";
	$sql2="INSERT INTO message SET username='$username';";
	$sql3="INSERT INTO notification SET username='$username';";
	$sql4="INSERT INTO pay SET username='$username';";
	$sql5="INSERT INTO ref SET username='$username',refer='$ref';";
	$sql6="CREATE TABLE $msgTable (id INT(8) NOT NULL AUTO_INCREMENT,you LONGTEXT,adminmsg LONGTEXT,PRIMARY KEY(id));";
	$sql7="CREATE TABLE $ntfTable (id INT(8) NOT NULL AUTO_INCREMENT,adminntf LONGTEXT,PRIMARY KEY(id));";
	$sql8="INSERT INTO $msgTable SET adminmsg='welcome'";
	$sql9="INSERT INTO $ntfTable SET adminntf='welcome'";
	//$sql2.="INSERT INTO ref SET username='$username',refer='$ref';";
	//$result=mysqli_multi_query($con,$sql);
	$con->autocommit(FALSE);
	$result=$con->query($sql);
	$result1=$con->query($sql1);
	$result2=$con->query($sql2);
	$result3=$con->query($sql3);
	$result4=$con->query($sql4);
	$result5=$con->query($sql5);
	$result6=$con->query($sql6);
	$result7=$con->query($sql7);
	$result8=$con->query($sql8);
	$result9=$con->query($sql9);
if(($result+$result1+$result2+$result3+$result4+$result5+$result6+$result7+$result8+$result9)==10){
	$_SESSION['username']=$username;
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Registered')
    window.location.href='index.php';
    </SCRIPT>");	
	$con->commit();
	
	
}
else{
	$con->rollback();
	echo "failed. ".$con->error;
	
}

	//if ($result){
		//echo $con->error;
		//$r2=mysqli_multi_query($con,$sql2);
		//if($r2){
			//$x=$con->query($sql4);
			//$y=$con->query($sql3);
			
			
		//$_SESSION['username']=$username;
		//echo ("<SCRIPT LANGUAGE='JavaScript'>
   // window.alert('Succesfully Registered')
   // window.location.href='index.php';
    //</SCRIPT>");	
	//	}
		//else{
		//echo "failed 2. ".$con->error;	
			
		//}
		
	
	//}
	//else{
		
	//	echo "failed ";
//		echo $con->error;
	
//}
}

else if(isset($_POST['login'])){
	
	$login=0;
	$usernameInpt=$_POST['usernameInpt'];
	$passInpt=md5($_POST['passInpt']);
	
	$sqlForLogin="SELECT username,pass FROM user;";
	
      $resultForLogin=$con->query($sqlForLogin);
      while($Result=mysqli_fetch_assoc($resultForLogin)){
          if ($usernameInpt==$Result['username'] && $passInpt==$Result['pass']){
              $_SESSION['status']=1;
            //  setcookie("status",1);
               $_SESSION['username']=$usernameInpt;
               // setcookie("username",$usernameForLogin);
			   $login=1;
	  }}
            if($login==1){  
              echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Logged In')
    window.location.href='./logged.php';
    </SCRIPT>");
			}
	
	
	else{
		$_SESSION['status']=0;
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Wrong Username Or Password')
    window.location.href='index.php';
    </SCRIPT>");
	}	
	
	}
	
		
	
	//echo $_SESSION['status']. "   Rahat   ".$_SESSION['username'];

?>