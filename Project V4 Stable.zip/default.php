<body style="background: url('wall.jpg');
  background-repeat: no-repeat;
  background-size: auto;"></body>
  hi