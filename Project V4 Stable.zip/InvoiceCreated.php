<div class="modal fade" id="InvoiceCreatedModal" tabindex="-1" role="dialog" aria-labelledby="InvoiceCreatedModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title" id="exampleModalLabel">Invoice Created !!!</h1>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
          <div class="text-success">
           <h3> We Have Received This Invoice! You Will Be Paid Soon!Check Out Your All Invoices From The 'Invoice' Section Of The Menu.</h3>
          </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Okay</button>
      </div>
    </div>
  </div>
</div>
<script>
$('#InvoiceCreatedModal').modal('show')

</script>