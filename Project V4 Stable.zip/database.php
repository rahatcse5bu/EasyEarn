
<?php

      include "config.php";
	  
	  if ((!$_SESSION['username'] == '') || (isset($_SESSION['username'])) ){
    $u=$_SESSION['username'];
}
    
	//echo "rahaat";
     //echo $u;
	// $u="rahatcse5bu";
	$x=$u."_msg";
	$y=$u."_ntf";
      $sqlx="SELECT * FROM user,$x,$y,message,notification,balance  WHERE user.username='$u' AND message.username='$u' AND notification.username='$u' AND balance.username='$u'  ;";
      $result=$con->query($sqlx);
      if($result){
     while($ro=mysqli_fetch_assoc($result)){
     
     $email= $ro['email'];
    $pass= $ro['pass'];
	$ads=$ro['id'];
	$msg=$ro['adminmsg'];
    $ntf=$ro['adminntf'];
	$bal_total=$ro['total_balance'];
	$bal_now=$ro['balance_now'];
	//echo "Working";
      }
	  
//echo "Workedd";
      }
      else{
          echo $con->error;
      }
       $dt=date("Y/m/d");
      $c="SELECT COUNT(*) FROM ads WHERE username='$u' AND date='$dt' GROUP BY(username);";
	  $r=$con->query($c);
	  while($row=mysqli_fetch_assoc($r)){
    
	$t=$row['COUNT(*)'];
    
      }
	//  echo $x."    ".$y;
	   
	   if (!$ntf){
		 $ntf="No Notification!";  
	   }
	   if(!$msg){
		   $msg="No Message From Admin";
	   }
      
      
      ?>