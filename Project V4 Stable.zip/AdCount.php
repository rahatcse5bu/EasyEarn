<?php
session_start();
?>
<?php
$u=$_SESSION['username'];
include "config.php";
include "Get.php";
//include"database.php";
$d=date("Y_m_d");
$sqlForDate="CREATE TABLE IF NOT EXISTS $d (

username VARCHAR(80),
ads INT(9) NOT NULL DEFAULT 0,
quiz INT(9) NOT NULL DEFAULT 0,
 PRIMARY KEY(username)

);";
$c=0;
$resultForDate=$con->query($sqlForDate);
$sqlForUserInsert="INSERT IGNORE INTO $d SET username='$u';";
$resultForUserInsert=$con->query($sqlForUserInsert);
if($resultForUserInsert){
//echo "insertion True";	
}
$sqlForCount="SELECT * FROM $d WHERE username='$u'";
$resultForCount=$con->query($sqlForCount);
if($resultForCount){
while($roo=mysqli_fetch_assoc($resultForCount)){
	$c=$roo['ads'];
	
}
//echo "  true7";
}
if($c<$tad){
$u=$_SESSION['username'];
//$d=date("Y/m/d");
/*
$c=$c+1;
$sql="UPDATE $d SET ads='$c' WHERE username='$u'";
$sqlForStore="UPDATE balance SET balance_now=balance_now+2,total_balance=total_balance+2 WHERE username='$u'";
$resultForStore=$con->query($sqlForStore);
$result=$con->query($sql);
if (($result)&&($resultForStore)){
	//include "NextAds.php";
	//echo "Watched";
}
else{
	echo "Error Occuredddddddddddddd".$con->error;
}
*/

echo "<p style='font-family: sevenSegment;' class='text-info';>"."You Have Watched: ".$c."<br>"."Ads Left For Today: "; echo $tad-$c.'</p>';

}
else{
	//echo "You Have Already Watched all the ads";
	//include "AdDone.php";
	$done=1;
	echo "<p style='font-family: sevenSegment;' class='text-info';>"." No More Ads Available";
	echo '<script type="text/javascript">$(document).ready(function (){ $("#wa").attr("disabled","disabled")}); </script>';
}


?>
<head>
<style type="text/css">
@font-face{
	
	font-family: sevenSegment;
	src: url("SevenSegment.ttf");
	
}

</style>
</head>
