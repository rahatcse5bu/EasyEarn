<script type="text/javascript">

alert("Hi Rahat");
</script>