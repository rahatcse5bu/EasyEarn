

<div class="container">
  <div class="row">
    <div class="col-sm">
  <!---    One of three columns --->
    </div>
  <div class="col-sm">
     <!---    One of three columns --->
    </div>
    <div class="col-sm">
     <!---    One of three columns --->
    </div>
  </div>
</div>


<div class="container">
  <div class="row">
    <div class="col-sm">
  <!---    One of three columns --->
    </div>
  <div class="alert alert-success" role="alert">
<?php include "database.php"; echo $ntf;  ?>
  
</div>
    <div class="col-sm">
     <!---    One of three columns --->
    </div>
  </div>
</div>







