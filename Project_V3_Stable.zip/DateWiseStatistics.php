<?php
session_start();
?>

<?php
$dt=0;
include "config.php";
$u=$_SESSION['username'];
$dd=$_POST['s_date'];
$dl=$_POST['e_date'];



echo '<div class="table-responsive">
<table class="table table-striped table-bordered table-hover">
  <thead>
    <tr>
      <th scope="col" class="table-primary" >Date</th>
      <th scope="col" class="table-success">Ad Views</th>
      <th scope="col" class="table-warning">Ad Income</th>
	  <th scope="col" class="table-success">Quiz Completed</th>
      <th scope="col" class="table-warning">Quiz Income</th>
	   
    </tr>
  </thead>
  <tbody>
    <tr>';



// Loop Start
while (1){
$x=substr($dd,6,4);
$x=$x."_";
$x=$x.substr($dd,0,2);
$x=$x."_";
$x=$x.substr($dd,3,2);
//$x=date("Y_m_d",$dd);
$sqlForStat="SELECT * FROM $x WHERE username='$u'";
//$x=$dd;
$resultForStat=$con->query($sqlForStat);
if($resultForStat){
if($row = mysqli_num_rows($resultForStat)){



	
	while($r=mysqli_fetch_assoc($resultForStat)){
		$dt++;
		echo '<th scope="row">'.$dd.'</th>';
		echo '<th scope="row">'.$r["ads"].'</th>';
		echo '<th scope="row">'.($r["ads"]*2).'</th>';
		echo '<th scope="row">'.$r["quiz"].'</th>';
		echo '<th scope="row">'.($r["quiz"]*2).'</th>';
		//echo '<th scope="row">'.$r["amount"].'</th>';
		//echo '<th scope="row">'.$r["status"].'</th>';
		//echo '<th scope="row">'.$r["Requested"].'</th>';
      
    echo '</tr>';
		
		
	}
	
	  //echo '</tbody></table></div>';
	
}

else{

//echo '<p class="text-primary" align="center">'."No Refer  data Yet !!!".'</p>';
//echo $x;
//$dd = strtotime("+1 day", strtotime($dd));
//echo date("Y-m-d", $dd);
      
}
}
else {
	//echo "error occured";
}
if ($dd==$dl){
	break;
}

$dd = strtotime("+1 day", strtotime($dd));
$dd=date("m/d/Y", $dd);
//echo $dd;


}	
	
	echo '</tbody></table></div>';
      ?>