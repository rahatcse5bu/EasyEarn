
<?php
session_start();

?>

<?php
$u=$_SESSION['username'];
include "config.php";
$ct=0;
$dt=date("Y_m_d");
$ss="SELECT * FROM $dt d WHERE username IN ( SELECT username FROM  user WHERE ref='$u' ) ON u.ref=d.username WHERE u.ref='$u'";
$r=$con->query($ss);
if ($r){
while($rw=mysqli_fetch_assoc($r)){
	$ct=$rw['ads'];
	
}
}
else{
	$ct=0;
}
echo 1*$ct;


?>